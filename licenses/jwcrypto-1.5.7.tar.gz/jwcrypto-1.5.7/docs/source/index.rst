.. JWCrypto documentation master file, created by
   sphinx-quickstart on Tue Apr 14 10:25:10 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to JWCrypto's documentation!
====================================

JWCrypto is an implementation of the Javascript Object Signing and
Encryption (JOSE) Web Standards as they are being developed in the
JOSE_ IETF Working Group and related technology.

JWCrypto uses the Cryptography_ package for all the crypto functions.

.. _JOSE: https://datatracker.ietf.org/wg/jose/charter/
.. _Cryptography: https://cryptography.io/

.. toctree::
   :maxdepth: 2
   :caption: Public APIs

   jwk
   jws
   jwe
   jwt
   common

.. toctree::
   :maxdepth: 2
   :caption: Internals

   jwa


Note: In the examples, random or generated output values are replaced
with '...' to allow for doctesting. Where possible the immutable part of
a token has been preserved, and only the variable part replaced with '...'

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
